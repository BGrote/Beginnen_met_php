<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="order-details">
        <h2>Your Order</h2>
        <ul>
            <li>Pizza Margherita: <?php echo $aantalmargarita; ?></li>
            <li>Pizza Funghi: <?php echo $aantalfunghi; ?></li>
            <li>Pizza Mariana: <?php echo $aantalmariana; ?></li>
            <li>Pizza Hawai: <?php echo $aantalhawai; ?></li>
            <li>Pizza Quattro Formaggi: <?php echo $aantalquattro; ?></li>
            <li>Total Price: €<?php echo number_format($totaalprijs, 2); ?></li>
        </ul>
    </div>
</body>
</html>